import json
import logging
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode
from urllib.request import Request, urlopen


TOKEN_URL = "https://www.linkedin.com/oauth/v2/accessToken"


@dataclass
class LinkedInToken:
    access_token: str
    expires_at_unix: float
    scope: str | None = None

    @property
    def is_expired(self) -> bool:
        # Refresh a bit early to avoid edge-of-expiry failures
        return time.time() >= (self.expires_at_unix - 60)


def _http_json(url: str, method: str, headers: dict[str, str] | None = None, body: bytes | None = None,
              timeout: int = 30) -> tuple[int, dict[str, Any]]:
    req = Request(url=url, method=method, data=body)
    for k, v in (headers or {}).items():
        req.add_header(k, v)
    if body is not None and "Content-Type" not in (headers or {}):
        req.add_header("Content-Type", "application/x-www-form-urlencoded")
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return resp.status, json.loads(raw) if raw else {}
    except Exception as e:
        # urllib raises HTTPError for non-2xx which is also an Exception with .read(); keep it simple here.
        if hasattr(e, "code") and hasattr(e, "read"):
            raw = e.read().decode("utf-8", errors="replace")
            try:
                return int(e.code), json.loads(raw) if raw else {}
            except Exception:
                return int(e.code), {"error": "http_error", "raw": raw}
        raise


def refresh_access_token(*, client_id: str, client_secret: str, refresh_token: str) -> LinkedInToken:
    """Exchange a LinkedIn refresh token for an access token.

    Note: LinkedIn refresh tokens are long-lived; keep them server-side only.
    """
    form = urlencode({
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
        "client_id": client_id,
        "client_secret": client_secret,
    }).encode("utf-8")

    status, payload = _http_json(TOKEN_URL, "POST", body=form)
    if status < 200 or status >= 300:
        raise RuntimeError(f"LinkedIn token refresh failed ({status}): {payload}")

    access_token = payload.get("access_token")
    expires_in = int(payload.get("expires_in", 0))
    if not access_token or expires_in <= 0:
        raise RuntimeError(f"LinkedIn token refresh returned unexpected payload: {payload}")

    return LinkedInToken(
        access_token=access_token,
        expires_at_unix=time.time() + expires_in,
        scope=payload.get("scope"),
    )


def get_org_posts_rest(
    *,
    access_token: str,
    org_urn: str,
    count: int = 10,
    start: int = 0,
    linkedin_version: str = "202502",
    max_retries: int = 4,
) -> dict[str, Any]:
    """REST-only: Find posts by organization author.

    Returns raw JSON from /rest/posts finder.
    """
    return get_rest_posts_url(
        access_token=access_token,
        url=_build_posts_finder_url(org_urn=org_urn, count=count, start=start),
        linkedin_version=linkedin_version,
        max_retries=max_retries,
    )


def _build_posts_finder_url(*, org_urn: str, count: int, start: int) -> str:
    # Keep encoding minimal: urlencode will encode ':' and other reserved characters in the URN,
    # which is required for the /rest/posts finder.
    query = urlencode({
        "q": "author",
        "author": org_urn,
        "count": str(max(1, int(count))),
        "start": str(max(0, int(start))),
        "sortBy": "LAST_MODIFIED",
    })
    return f"https://api.linkedin.com/rest/posts?{query}"


def get_rest_posts_url(
    *,
    access_token: str,
    url: str,
    linkedin_version: str = "202502",
    max_retries: int = 4,
) -> dict[str, Any]:
    """Fetch an arbitrary LinkedIn REST URL (used for paging via paging.links[].href)."""
    # Accept relative hrefs like "/rest/posts?..." and normalize.
    if url.startswith("/"):
        url = "https://api.linkedin.com" + url

    headers = {
        "Authorization": f"Bearer {access_token}",
        "X-Restli-Protocol-Version": "2.0.0",
        "Linkedin-Version": linkedin_version,
        "X-RestLi-Method": "FINDER",
        "Accept": "application/json",
    }

    backoff = 0.5
    last_payload: dict[str, Any] | None = None

    for attempt in range(1, max_retries + 1):
        status, payload = _http_json(url, "GET", headers=headers)
        last_payload = payload

        if 200 <= status < 300:
            return payload

        # Retry on 429 + 5xx only
        if status == 429 or (500 <= status < 600):
            logging.warning("LinkedIn REST posts retry %s/%s (status=%s)", attempt, max_retries, status)
            time.sleep(backoff)
            backoff = min(backoff * 2, 8.0)
            continue

        raise RuntimeError(f"LinkedIn REST posts failed ({status}): {payload}")

    raise RuntimeError(f"LinkedIn REST posts failed after retries: {last_payload}")
