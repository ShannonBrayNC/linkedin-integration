import json
import os
import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="health", methods=["GET"])
def health(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse("ok", status_code=200)

@app.route(route="dev/session", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def dev_session(req: func.HttpRequest) -> func.HttpResponse:
    enabled = (req.params.get("enabled") or "false").lower() == "true"
    return func.HttpResponse(f"dev session enabled={enabled}", status_code=200)

@app.route(route="linkedin/org/posts", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def linkedin_org_posts(req: func.HttpRequest) -> func.HttpResponse:
    # Lazy import so health endpoint survives even if deps are missing during a bad deploy
    try:
        import requests
    except Exception as e:
        body = {
            "syncStatus": "DEGRADED",
            "total": 0,
            "items": {},
            "explanation": "Python dependency missing: requests",
            "error": str(e),
        }
        return func.HttpResponse(json.dumps(body, indent=2), status_code=200, mimetype="application/json")

    org_urn = req.params.get("orgUrn") or ""
    count = int(req.params.get("count") or "10")
    start = int(req.params.get("start") or "0")

    # You likely plug your token retrieval here
    access_token = os.getenv("LI_ACCESS_TOKEN", "")

    if not access_token:
        body = {
            "syncStatus": "DEGRADED",
            "total": 0,
            "items": {},
            "explanation": "No valid LinkedIn auth configured (no LI_ACCESS_TOKEN).",
            "source": "none",
        }
        return func.HttpResponse(json.dumps(body, indent=2), status_code=200, mimetype="application/json")

    # Placeholder LinkedIn call scaffolding (keep your real endpoint logic if you already had it)
    headers = {"Authorization": f"Bearer {access_token}"}
    # url = "https://api.linkedin.com/..."  # your real posts endpoint
    # resp = requests.get(url, headers=headers, timeout=30)

    body = {
        "syncStatus": "OK",
        "total": 0,
        "items": [],
        "explanation": "requests import OK; wire your LinkedIn call here.",
        "orgUrn": org_urn,
        "count": count,
        "start": start,
    }
    return func.HttpResponse(json.dumps(body, indent=2), status_code=200, mimetype="application/json")
